#!/bin/sh
cpx -c ~/new/imail $scm/.
