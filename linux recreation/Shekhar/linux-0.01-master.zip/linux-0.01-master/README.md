linux-0.01
==========

Historical 0.01 release of linux kernel taken from here ftp://ftp.kernel.org/pub/linux/kernel/Historic/
